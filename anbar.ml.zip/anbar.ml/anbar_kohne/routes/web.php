<?php

use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\xercController;
use App\Http\Controllers\brandsController;
use App\Http\Controllers\ordersController;
use App\Http\Controllers\clientsController;
use App\Http\Controllers\emailController;
use App\Http\Controllers\profileController;
use App\Http\Controllers\employeeController;
use App\Http\Controllers\newpassController;
use App\Http\Controllers\productsController;
use App\Http\Controllers\loginController;
use App\Http\Controllers\qeydiyyatController;
use App\Http\Controllers\ForgotPasswordController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::group(['middleware'=>'isLogin'],function(){

    Route::get('/myprofile', [profileController::class, 'index'])->name('myprofile');
    Route::post('/myprofile_ins', [profileController::class, 'store']);

    Route::get('/', [clientsController::class, 'index'])->name('clients');
    Route::post('clients_ins', [clientsController::class, 'store']);
    Route::post('clients_edit', [clientsController::class, 'edit']);
    Route::post('clients_delete', [clientsController::class, 'destroy']); 
    
    Route::get('/brands', [brandsController::class, 'index'])->name('brands');
    Route::post('brands_ins', [brandsController::class, 'store']);
    Route::post('brands_edit', [brandsController::class, 'edit']);
    Route::post('brands_delete', [brandsController::class, 'destroy']);

    Route::get('/products', [productsController::class, 'index'])->name('products');
    Route::post('products_ins', [productsController::class, 'store']);
    Route::post('products_edit', [productsController::class, 'edit']);
    Route::post('products_delete', [productsController::class, 'destroy']);

    Route::get('/orders', [ordersController::class, 'index'])->name('orders');
    Route::post('orders_ins', [ordersController::class, 'store']);
    Route::post('orders_edit', [ordersController::class, 'edit']);
    Route::post('orders_delete', [ordersController::class, 'destroy']);
    Route::post('orders_tesdiq', [ordersController::class, 'tesdiq']);
    Route::post('orders_legv', [ordersController::class, 'legv']);

    Route::get('/xerc', [xercController::class, 'index'])->name('xerc');
    Route::post('xerc_ins', [xercController::class, 'store']);
    Route::post('xerc_edit', [xercController::class, 'edit']);
    Route::post('xerc_delete', [xercController::class, 'destroy']);

    Route::get('/employee', [employeeController::class, 'index'])->name('employee');
    Route::post('employee_ins', [employeeController::class, 'store']);
    Route::post('employee_edit', [employeeController::class, 'edit']);
    Route::post('employee_delete', [employeeController::class, 'destroy']);

    //Logout
    Route::get('/logout','App\Http\Controllers\loginController@logout')->name('exit');
});

Route::group(['middleware'=>'notLogin'],function(){

    //Qeydiyyat
    Route::get('/qeydiyyat', function () {return view ('qeydiyyat');})->name('qeydiyyat');
    Route::post('qeydiyyat',[qeydiyyatController::class, 'user_ins'])->name('user_ins');

    Route::get('/login', function () { return view ('login'); })->name('login');
    Route::post('login',[loginController::class, 'login'])->name('login'); 
    
    Route::get('/forget_pass', function () { return view ('email'); })->name('forget_pass');
    Route::post('forget_pass',[emailController::class, 'store'])->name('email'); 

    Route::get('/new-pass/{eid}', function () { return view ('new-pass'); })->name('new-pass');
    Route::post('new-pass',[newpassController::class, 'store']);
});
 
