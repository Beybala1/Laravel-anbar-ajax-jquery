<?php namespace App\Http\Controllers;

use App\Models\User;
use App\Models\brands;
use App\Models\orders;
use App\Models\clients;
use App\Models\products;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests\profileRequest;

class profileController extends Controller {
    
    public function index(){
        
        return view('myprofile',[

            'products_data'=>products::orderby('id','desc')->where('products.user_id','=',Auth::id())
            ->join('brands','brands.id','=','products.brands_id')
            ->select('products.id','products.ad as mehsul','products.alis','products.foto','products.user_id',
            'products.satis','products.miqdar','products.created_at','brands.ad')
            ->get(),

            //Cari qazanc
            'orders_data'=>orders::join('clients','clients.id','=','orders.clients_id')
            ->join('products','products.id','=','orders.product_id')
            ->join('brands','brands.id','=','products.brands_id')
            ->select('orders.id','orders.miqdar as order_miqdar','orders.created_at','orders.tesdiq',
            'products.ad as mehsul','products.miqdar','products.foto','products.alis','products.user_id',
            'products.satis','brands.ad as brend','clients.ad as client','clients.soyad')
            ->where('orders.user_id','=',Auth::id())
            ->orderby('id','desc')
            ->get(),

            'total_client'=>clients::where('user_id','=',Auth::id())->count(),
            'total_brand'=>brands::where('user_id','=',Auth::id())->count(),
            'total_product'=>products::where('user_id','=',Auth::id())->count(),
            'total_order'=>orders::where('user_id','=',Auth::id())->count(),
        ]);
    }
    
    public function store(profileRequest $post){
   
        $con = User::find(Auth::id());

        if(Hash::check($post->cari_parol,$con->password)){

            if(empty($post->yeni_parol) or strlen($post->yeni_parol)>2){

                if($post->yeni_parol==$post->parol_t){

                    if($post->file('foto')){

                        $post->validate([
                            'foto' => 'image|mimes:jpg,png,jpeg,gif,svg|max:2048',
                        ]);
                        
                        $file = time().'.'.$post->foto->extension();
                        $post->foto->storeAS('uploads/profile/',$file);
                        $con -> foto = 'storage/app/uploads/profile/'.$file;
                    }
                    else{
                        $con->foto = $post->carifoto;
                    } 
                    
                    if($post->yeni_parol>3){
                        $con->password = Hash::make($post->yeni_parol);
                    }
                    else{
                        $con->name = $post->ad;
                        $con->email = $post->email;
                    }
                
                    $con->save();

                    return redirect()->route('myprofile')->with('success','Dəyişikliklər uğurla yadda saxlanildi');
                }
                return redirect()->route('myprofile')->with('fail','Yeni parol ilə təkrar parol uyğun deyil');
            }
            return redirect()->route('myprofile')->with('fail','Yeni parol 3 simovoldan az ola bilməz');
        }
        return redirect()->route('myprofile')->with('fail','Cari parol yanlişdir');
    }
}
