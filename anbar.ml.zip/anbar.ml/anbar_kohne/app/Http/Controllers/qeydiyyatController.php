<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests\qeydiyyatRequest;

class qeydiyyatController extends Controller
{
    public function user_ins(qeydiyyatRequest $post){

        date_default_timezone_set('Asia/Baku');
        
        $con = new User();

        $email = md5($post->email);

        $to = $post->email;

        $subject = "Qeydiyyat";

        $m = '';

        $m .='<h1 style="text-align:center;">Anbar</h1><h3 style="color:green; text-align: center;">
        Qeydiyyatı uğurla tamamlamaq üçün aşağıdakı "Tesdiq et" düyməsinə basın</h3>
        <a style="text-decoration:none;" href="https://anbar.ml/tesdiq.php?eid='.$email.'">
        <button style="margin:0 40%; padding:1.2% 7%; background-color:green; border:none; color:white;">Tesdiq et</button></a>'."\n\n"; 
        
        $headers = "From: anbar@info.az\r\n" . "X-Mailer: php"; //mail headers
        $headers.= 'MIME-Version: 1.0' . "\r\n";
        $headers.= 'Content-type: text/html; charset=utf-8 \r\n';

        $say = $con->where('email','=',$post->email)->count();

        if($say == 0){

            if($post->parol==$post->parol_t){

                $con->name = $post->ad;
                $con->email = $post->email; 
                $con->password = Hash::make($post->parol);
                $con->foto = 'https://anbar.ml/no-image.gif';
                $con->tesdiq = 0;
               
                $con->save();                
                
                mail($to, $subject, $m, $headers,);

                return redirect()->route('qeydiyyat')->with('success','Məlumat email-a uğurla göndərildi');
            }
            return redirect()->route('qeydiyyat')->with('fail','Parol ilə təkrar parol uyğun deyil');
        }
        return redirect()->route('qeydiyyat')->with('fail','Bu email bazada mövcuddur');
    }
}
