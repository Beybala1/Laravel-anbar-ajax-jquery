<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\pass_resets;
use Illuminate\Http\Request;

class emailController extends Controller
{
    public function store(Request $request){

        $new = new pass_resets();

        $email = md5($request->email);

        $to = $request->email;

        $subject = "Şifrəni dəyiş";

        $m = '';

        $m .='<h1 style="text-align:center;">Anbar</h1><h3 style="color:green; text-align: center;">Şifrənizi dəyişdirmək istəyirsinizsə zəhmət olmasa "Şifrəni dəyiş" düyməsinə basin</h3>
        <a style="text-decoration:none;" href="https://anbar.ml/new-pass/'.$email.'">
        <button style="margin:0 40%; padding:1.2% 7%; background-color:green; border:none; color:white;">Şifrəni dəyiş</button></a>'."\n\n";
        
        $headers = "From: anbar@info.az\r\n" . "X-Mailer: php"; //mail headers
        $headers.= 'MIME-Version: 1.0' . "\r\n";
        $headers.= 'Content-type: text/html; charset=utf-8 \r\n';

        $user = User::where('email','=',$request->email)->count();

        if($user>0){ 
            
            mail($to, $subject, $m, $headers);
            
            return redirect()->route('forget_pass')->with('success','Məlumat email-a uğurla göndərildi');
        }
        return redirect()->route('forget_pass')->with('fail','Daxil etdiyiniz email anbarda mövcud deyil');
    }
}

