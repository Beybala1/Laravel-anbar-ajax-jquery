<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\clients;

use Datatables;

class AjaxCRUDImageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(request()->ajax()) {
            return datatables()->of(clients::select('*'))
            ->addColumn('action', 'book-action')
            ->addColumn('image', 'image')
            ->rawColumns(['action','image'])
            ->addIndexColumn()
            ->make(true);
        }
        return view('book-list');
    }
     
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {  

        $bookId = $request->id;

        if($bookId){
            date_default_timezone_set('Asia/Baku');
            $book = clients::find($bookId);

            if($request->hasFile('foto')){
                $path = $request->file('foto')->store('public/fotos');
                $book->foto = $path;
            }   
        }else{
                $path = $request->file('foto')->store('public/fotos');
                $book = new clients;
                $book->foto = $path;
        }
         
        $book->ad = $request->ad;
        $book->soyad = $request->soyad;
        $book->tel = $request->tel;
        $book->email = $request->email;
        $book->user_id = $request->Auth::id();;
        $book->save();
     
        return Response()->json($book);
    }
     
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\book  $book
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {   
        $where = array('id' => $request->id);
        $book  = clients::where($where)->first();
     
        return Response()->json($book);
    }
     
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\book  $book
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $book = clients::where('id',$request->id)->delete();
     
        return Response()->json($book);
    }
}