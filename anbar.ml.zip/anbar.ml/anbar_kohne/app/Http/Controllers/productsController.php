<?php

namespace App\Http\Controllers;

use App\Models\brands;
use App\Models\orders;
use App\Models\clients;
use App\Models\products;
use Illuminate\Http\Request;
use App\Exports\productsExport;
use App\Imports\productsImport;
use Yajra\DataTables\DataTables;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Requests\productsRequest;

class productsController extends Controller
{
     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(request()->ajax()) {
            return datatables()->of(
                
                products::orderby('id','desc')
                ->join('brands','brands.id','=','products.brands_id')
                ->select('products.id','products.ad','products.alis','products.foto','products.user_id',
                'products.satis','products.miqdar','products.created_at','brands.ad as brand')
                ->where('products.user_id','=',Auth::id())
                ->get()
            )
            
            ->addColumn('action', 'book-action')
            ->addColumn('image', function($row){
                return $row->foto;
            })
            ->addColumn('created_at', function($row){
                return date('d-m-Y h:i:s', strtotime($row->created_at) );
            })
            ->addIndexColumn()
            ->make(true);
            
        }
        return view('products',[

                'brand_data'=>brands::orderbydesc('id')->where('user_id','=',Auth::id())->get(),

                //'brand_data'=>products::orderbydesc('id')->with('brands')->where('user_id','=',Auth::id())->get(),
             
                //Toplam qazancin statistikasi
                'products_data'=>products::orderby('id','desc')
                ->join('brands','brands.id','=','products.brands_id')
                ->select('products.id','products.ad as mehsul','products.miqdar','products.alis',
                'products.satis','brands.ad as brend')
                ->where('products.user_id','=',Auth::id())
                ->get(),
                
                //Cari qazanc
                'orders_data'=>orders::join('clients','clients.id','=','orders.clients_id')
                ->join('products','products.id','=','orders.product_id')
                ->join('brands','brands.id','=','products.brands_id')
                ->select('orders.id','orders.miqdar as order_miqdar','orders.created_at','orders.tesdiq',
                'products.ad as mehsul','products.miqdar','products.foto','products.alis',
                'products.satis','brands.ad as brend','clients.ad as client','clients.soyad')
                ->where('orders.user_id','=',Auth::id())
                ->orderby('id','desc')
                ->get(),
    
                'total_client'=>clients::where('user_id','=',Auth::id())->count(),
                'total_brand'=>brands::where('user_id','=',Auth::id())->count(),
                'total_product'=>products::where('user_id','=',Auth::id())->count(),
                'total_order'=>orders::where('user_id','=',Auth::id())->count(),
        ]);
    }
     
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {  
        $bookId = $request->id;

        if($bookId){
            date_default_timezone_set('Asia/Baku');
            $book = products::find($bookId);

            if($request->hasFile('foto')){

                $file = time().'.'.$request->foto->extension();
                $request->foto->storeAS('uploads/products/',$file);
                $book -> foto = 'storage/app/uploads/products/'.$file;
            }   
        }else{
                $book = new products;
                $file = time().'.'.$request->foto->extension();
                $request->foto->storeAS('uploads/products/',$file);
                $book -> foto = 'storage/app/uploads/products/'.$file;
        }
        
            $book->ad = $request->ad;
            $book->brands_id = $request->brend_id;
            $book->alis = $request->alis;
            $book->satis = $request->satis;
            $book->miqdar = $request->miqdar;
            $book->user_id = Auth::id();
            $book->save();
        
            return Response()->json($book);
    }
     
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\book  $book
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {   
        $where = array('products.id' => $request->id);
        /*$book  = products::where($where)->first();*/
        
        $book = products::orderby('id','desc')->where('products.user_id','=',Auth::id())
        ->join('brands','brands.id','=','products.brands_id')->where($where)
        ->select('products.id','products.ad as mehsul','products.alis','products.foto','products.user_id',
        'products.satis','products.miqdar','products.created_at','brands.ad as brend','brands.id as brand_id')->first();
      
        return Response()->json($book);
    }
    
    /**
     * 
     *
     * @param  \App\book  $book
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $con1 = orders::where('product_id','=',$request->id)->count();

        if($con1==0){

            $book = products::where('id',$request->id)->delete();
        
            return Response()->json($book);
        }
        return redirect()->back('products');
    }
















    /*
    public function products_ins(productsRequest $post){

        date_default_timezone_set('Asia/Baku');
        $con = new products();

        $post->validate([
            'foto' => 'required|image|mimes:jpg,png,jpeg,gif,svg|max:2048',
        ]);

        if($post->file('foto')){
            $file = time().'.'.$post->foto->extension();
            $post->foto->storeAS('public/uploads/products/',$file);
            $con -> foto = 'storage/uploads/products/'.$file;
        }

        $con->ad = $post->ad;
        $con->brands_id = $post->brend_id;
        $con->alis = $post->alis;
        $con->satis = $post->satis;
        $con->miqdar = $post->miqdar;
        $con->user_id = Auth::id();

        $con->save();

        return redirect()->route('products')->with('success','Məhsul uğurla daxil edildi');
    }

    public function products_list(){
        
        return view('products', [
            
            'brand_data'=>brands::orderby('ad','asc')->where('user_id','=',Auth::id())->get(),

            'products_data'=>products::orderby('id','desc')->where('products.user_id','=',Auth::id())
            ->join('brands','brands.id','=','products.brands_id')
            ->select('products.id','products.ad as mehsul','products.alis','products.foto','products.user_id',
            'products.satis','products.miqdar','products.created_at','brands.ad')
            ->get(),

            'data'=>products::orderbydesc('id')->with('brands')->where('user_id','=',Auth::id())->get(),
            'bdata'=>brands::orderbydesc('id')->with('products')->where('user_id','=',Auth::id())->get(),

            //Cari qazanc
            'orders_data'=>orders::join('clients','clients.id','=','orders.clients_id')
            ->join('products','products.id','=','orders.product_id')
            ->join('brands','brands.id','=','products.brands_id')
            ->select('orders.id','orders.miqdar as order_miqdar','orders.created_at','orders.tesdiq',
            'products.ad as mehsul','products.miqdar','products.foto','products.alis','products.user_id',
            'products.satis','brands.ad as brend','clients.ad as client','clients.soyad')
            ->where('orders.user_id','=',Auth::id())
            ->orderby('id','desc')
            ->get(),

            'total_client'=>clients::where('user_id','=',Auth::id())->count(),
            'total_brand'=>brands::where('user_id','=',Auth::id())->count(),
            'total_product'=>products::where('user_id','=',Auth::id())->count(),
            'total_order'=>orders::where('user_id','=',Auth::id())->count(),
        ]);
    }

    public function products_delete($id){

        return view('products',[

            'data'=>products::orderbydesc('id')->with('brands')->where('user_id','=',Auth::id())->get(),
            'bdata'=>brands::orderbydesc('id')->with('products')->where('user_id','=',Auth::id())->get(),

            //'sildata'=>products::orderbydesc('id')->with('brands')->where('brands.id','=','brands_id')->find($id),
          
            'sildata'=>products::join('brands','brands.id','=','products.brands_id')
            ->select('products.id','products.ad as mehsul','brands.ad')
            ->find($id),

            //Cari qazanc
            'orders_data'=>orders::join('clients','clients.id','=','orders.clients_id')
            ->join('products','products.id','=','orders.product_id')
            ->join('brands','brands.id','=','products.brands_id')
            ->select('orders.id','orders.miqdar as order_miqdar','orders.created_at','orders.tesdiq',
            'products.ad as mehsul','products.miqdar','products.foto','products.alis',
            'products.satis','brands.ad as brend','clients.ad as client','clients.soyad')
            ->where('orders.user_id','=',Auth::id())
            ->orderby('id','desc')
            ->get(),

            'total_client'=>clients::where('user_id','=',Auth::id())->count(),
            'total_brand'=>brands::where('user_id','=',Auth::id())->count(),
            'total_product'=>products::where('user_id','=',Auth::id())->count(),
            'total_order'=>orders::where('user_id','=',Auth::id())->count(),
        ]);
    }
    public function products_sil($id){

        products::find($id)->delete();
        return redirect()->route('products')->with('success','Mehsul uğurla silindi');
    }

    public function products_edit($id){

        return view('products',[

            'data'=>products::orderbydesc('id')->with('brands')->where('user_id','=',Auth::id())->get(),
            'bdata'=>brands::orderbydesc('id')->with('products')->where('user_id','=',Auth::id())->get(),

            'editdata'=>products::join('brands','brands.id','=','products.brands_id')
            ->select('products.id','products.ad as mehsul','products.alis','products.satis','products.foto',
            'products.miqdar','products.brands_id','brands.ad')
            ->find($id),

            //Cari qazanc
            'orders_data'=>orders::join('clients','clients.id','=','orders.clients_id')
            ->join('products','products.id','=','orders.product_id')
            ->join('brands','brands.id','=','products.brands_id')
            ->select('orders.id','orders.miqdar as order_miqdar','orders.created_at','orders.tesdiq',
            'products.ad as mehsul','products.miqdar','products.foto','products.alis',
            'products.satis','brands.ad as brend','clients.ad as client','clients.soyad')
            ->where('orders.user_id','=',Auth::id())
            ->orderby('id','desc')
            ->get(),

            'total_client'=>clients::where('user_id','=',Auth::id())->count(),
            'total_brand'=>brands::where('user_id','=',Auth::id())->count(),
            'total_product'=>products::where('user_id','=',Auth::id())->count(),
            'total_order'=>orders::where('user_id','=',Auth::id())->count(),
        ]);
    }

    public function products_update(productsRequest $post){

        $edit = products::find($post->id);

        if($post->file('foto')){

            $post->validate([
                'foto' => 'required|image|mimes:jpg,png,jpeg,gif,svg|max:2048',
            ]);

            $file = time().'.'.$post->foto->extension();
            $post->foto->storeAS('public/uploads/products/',$file);
            $edit ->foto = 'storage/uploads/products/'.$file;
        } 
        else{
            $edit -> foto = $post->carifoto;
        }

        $edit->brands_id = $post->brend_id;
        $edit->ad = $post->ad;
        $edit->alis = $post->alis;
        $edit->satis = $post->satis;
        $edit->miqdar = $post->miqdar;

        $edit->save();

        return redirect()->route('products')->with('success','Məhsul uğurla yeniləndi');
    }

    public function export(){
        return Excel::download(new productsExport,'Məhsullar.xlsx');
    }

    public  function  import(){
        Excel::download(new productsImport,request()->file('file'));
        return back();
    }*/
}
