<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Requests\newpassRequest;
use Illuminate\Support\Facades\Hash;

class newpassController extends Controller
{
    public function check($eid){
        $ok = 0;
        $user = User::get();

        foreach($user as $new_pass){
            
            $email = md5($new_pass->email);
            
            if($email==$eid)
            {$ok=1;}
        }

        if($ok==0)
        {return view('new-pass',['fail'=>'Bele bir email movcud deyil']);}
        else
        {return view('new-pass',['success'=>$eid]);}
    }

    public function store(Request $request){

        $user = User::get();

        foreach($user as $new_pass){
            
            $email = md5($new_pass->email);
            
            if($email==$request->eid)
            {
                $con = User::find($new_pass->id);
                $con->password = Hash::make($request->yeni_parol);
                return redirect()->route('new-pass',$email)->with('success','Parol uğurla yeniləndi');
            }
        }
        return redirect()->route('new-pass',$email)->with('fail','Xəta baş verdi');
    }
}
