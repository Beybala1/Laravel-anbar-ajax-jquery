<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class loginController extends Controller
{
    public function login(Request $post){

       $user = User::where('email','=',$post->email)->get();
       $tesdiq=$user[0]->tesdiq;

        if($tesdiq==1)
        {
            if(!Auth::attempt(['email'=>$post->email,'password'=>$post->parol]))
            {
                return redirect()->back()->with('fail','Login və ya parol yanlişdir');
            }
            return redirect()->route('clients');
        }
        else
        {return redirect()->back()->with('fail','Sizin profil dogrulanmayib. Emailinize daxil olaraq profilinizi dogrulayin');}
    }

    public function logout(){
        auth()->logout();
        return redirect()->route('login');
    }
}
