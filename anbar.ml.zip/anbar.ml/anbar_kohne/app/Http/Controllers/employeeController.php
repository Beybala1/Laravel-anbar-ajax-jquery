<?php

namespace App\Http\Controllers;

use Datatables;
use App\Models\brands;
use App\Models\orders;
use App\Models\clients;
use App\Models\employee;
use App\Models\products;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class employeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(request()->ajax()) {
            return datatables()->of(employee::select('*')->where('user_id','=',Auth::id()))
            ->addColumn('action', 'book-action')
            ->addColumn('image', function($row){
                return $row->image;
            })
            ->addColumn('created_at', function($row){
                return date('d-m-Y h:i:s', strtotime($row->created_at) );
            })
            ->addIndexColumn()
            ->make(true);
        }
        return view('employee',[

            //Toplam qazancin statistikasi
            'products_data'=>products::orderby('id','desc')
            ->join('brands','brands.id','=','products.brands_id')
            ->select('products.id','products.ad as mehsul','products.miqdar','products.alis',
            'products.satis','brands.ad as brend')
            ->where('products.user_id','=',Auth::id())
            ->get(),
            
            //Cari qazanc
            'orders_data'=>orders::join('clients','clients.id','=','orders.clients_id')
            ->join('products','products.id','=','orders.product_id')
            ->join('brands','brands.id','=','products.brands_id')
            ->select('orders.id','orders.miqdar as order_miqdar','orders.created_at','orders.tesdiq',
            'products.ad as mehsul','products.miqdar','products.foto','products.alis',
            'products.satis','brands.ad as brend','clients.ad as client','clients.soyad')
            ->where('orders.user_id','=',Auth::id())
            ->orderby('id','desc')
            ->get(),

            'total_client'=>clients::where('user_id','=',Auth::id())->count(),
            'total_brand'=>brands::where('user_id','=',Auth::id())->count(),
            'total_product'=>products::where('user_id','=',Auth::id())->count(),
            'total_order'=>orders::where('user_id','=',Auth::id())->count(),
        ]);
    }
     
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {  
        $bookId = $request->id;
        
        if($bookId){ 

            $book = employee::find($bookId);

            if($request->hasFile('image')){
                $file = time().'.'.$request->image->extension();
                $request->image->storeAS('uploads/employee/',$file);
                $book ->image = 'storage/app/uploads/employee/'.$file;
            }   
        }
        else{

            $book = new employee();

            $file = time().'.'.$request->image->extension();
            $request->image->storeAS('uploads/employee/',$file);
            $book ->image = 'storage/app/uploads/employee/'.$file;
        }

        date_default_timezone_set('Asia/Baku');

        $book->name = $request->name;
        $book->lastname = $request->lastname;
        $book->phone = $request->phone;
        $book->job = $request->job;
        $book->salary = $request->salary;
        $book->user_id = Auth::id();
        $book->save();
            
        return Response()->json($book);
    }
     
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\book  $book
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {   
        $where = array('id' => $request->id);
        $book  = employee::where($where)->first();
     
        return Response()->json($book);
    }
     
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\book  $book
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $book = employee::where('id',$request->id)->delete();
        return Response()->json($book);
    }
}
