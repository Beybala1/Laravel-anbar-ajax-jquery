<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Requests\newpassRequest;

class tesdiqController extends Controller
{
    public function store(Request $request){
        
        $user = User::get()->where('tesdiq','=','0');

        $tesdiq = 0;
        
        foreach($user as $user_tesdiq){
            
            if(md5($user_tesdiq->email)==$_GET['eid'])
            {
                $tesdiq = 1;
                
                $user_tesdiq->tesdiq = 1;
                
                if($user_tesdiq->tesdiq = 1){
                   return redirect()->route('qeydiyyat')->with('success','Qeydiyyat uğurla həyata keçirildi');
                }
                return redirect()->route('qeydiyyat')->with('fail','Qeydiyyat uğursuz oldu');
            }
        }
    }
}