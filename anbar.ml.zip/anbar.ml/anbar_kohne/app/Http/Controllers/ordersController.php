<?php

namespace App\Http\Controllers;

use Storage;
use Datatables;
use App\Models\brands;
use App\Models\orders;
use App\Models\clients;
use App\Models\products;
use Illuminate\Http\Request;
use App\Exports\ordersExport;
use App\Imports\ordersImport;
use App\Http\Requests\ordersRequest;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\DB;

class ordersController extends Controller
{
     /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(request()->ajax()) {
            
            return datatables()->of(

                orders::join('clients','clients.id','=','orders.clients_id')
                ->join('products','products.id','=','orders.product_id')
                ->join('brands','brands.id','=','products.brands_id')
                ->select('orders.id','orders.miqdar as order_miqdar','orders.created_at','orders.tesdiq',
                'products.ad as mehsul','products.miqdar','products.foto','products.alis','products.user_id',
                'products.satis','brands.ad as brend',clients::raw("CONCAT(clients.ad,' ',clients.soyad) as client"))
                ->where('orders.user_id','=',Auth::id())
                ->orderby('id','desc')
                ->get()
            )
            ->addColumn('action',  function($row){
                
                if($row->tesdiq==0){
                    return '
                    
                    <a href="javascript:void(0);" id="" data-toggle="tooltip" data-original-title="Təsdiq" data-id="'.$row->id.'" class="tesdiq btn btn-primary">
                        <ion-icon name="checkmark-circle-outline"></ion-icon>
                    </a>

                    <a href="javascript:void(0)" data-toggle="tooltip"  data-id="'.$row->id.'" data-original-title="Edit" class="edit btn btn-success edit">
                        <ion-icon name="create"></ion-icon>
                    </a>

                    <a href="javascript:void(0);" id="delete-book" data-toggle="tooltip" data-original-title="Delete" data-id="'.$row->id.'" class="delete btn btn-danger">
                        <ion-icon name="trash"></ion-icon>
                    </a>';
                }

                else{
                    return'
                    <a href="javascript:void(0);" id="" data-toggle="tooltip" data-original-title="" data-id="'.$row->id.'" class="legv btn btn-warning">
                        <ion-icon name="close-circle-outline"></ion-icon>
                    </a>';
                }
            })
            ->addColumn('created_at', function($row){
                return date('d-m-Y h:i:s', strtotime($row->created_at) );
            })
            ->addIndexColumn()
            ->make(true);
        }

        return view('orders',[
            'client_data'=>clients::orderby('ad','asc')->where('user_id','=',Auth::id())->get(),
            'product_data'=>products::orderbydesc('id')->with('brands')->where('user_id','=',Auth::id())->get(),

                //Toplam qazancin statistikasi
                'products_data'=>products::orderby('id','desc')
                ->join('brands','brands.id','=','products.brands_id')
                ->select('products.id','products.ad as mehsul','products.miqdar','products.alis',
                'products.satis','brands.ad as brend')
                ->where('products.user_id','=',Auth::id())
                ->get(),
                
                //Cari qazanc
                'orders_data'=>orders::join('clients','clients.id','=','orders.clients_id')
                ->join('products','products.id','=','orders.product_id')
                ->join('brands','brands.id','=','products.brands_id')
                ->select('orders.id','orders.miqdar as order_miqdar','orders.created_at','orders.tesdiq',
                'products.ad as mehsul','products.miqdar','products.foto','products.alis',
                'products.satis','brands.ad as brend','clients.ad as client','clients.soyad')
                ->where('orders.user_id','=',Auth::id())
                ->orderby('id','desc')
                ->get(),
    
                'total_client'=>clients::where('user_id','=',Auth::id())->count(),
                'total_brand'=>brands::where('user_id','=',Auth::id())->count(),
                'total_product'=>products::where('user_id','=',Auth::id())->count(),
                'total_order'=>orders::where('user_id','=',Auth::id())->count(),
        ]);
    }
     
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {  
        $bookId = $request->id;

        if($bookId){
            date_default_timezone_set('Asia/Baku');
            $book = orders::find($bookId);

           /*if($request->hasFile('foto')){
                $path = $request->file('foto')->store('public/fotos');
                $book->foto = $path;
            }   */
        }else{
                //$path = $request->file('foto')->store('public/fotos'); 
                $book = new orders;
               // $book->foto = $path;
        }
        
            $book->clients_id = $request->clients_id;
            $book->product_id = $request->product_id;
            $book->miqdar = $request->miqdar;
            $book->tesdiq = 0;
            $book->user_id = Auth::id();
            $book->save();
        
            return Response()->json($book);
    }
     
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\book  $book
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {   
        $where = array('orders.id' => $request->id);
        //$book  = orders::where($where)->first();

        $book = orders::join('clients','clients.id','=','orders.clients_id')
        ->join('products','products.id','=','orders.product_id')
        ->join('brands','brands.id','=','products.brands_id')
        ->select('orders.id','orders.miqdar as order_miqdar','orders.created_at','orders.tesdiq','products.id as product_id',
        'products.ad as mehsul','products.miqdar','products.foto','products.alis','products.user_id',
        'products.satis','brands.id as brend_id','brands.ad as brend','clients.ad as client','clients.soyad','clients.id as client_id')
        ->orderby('id','desc')->where('orders.user_id','=',Auth::id())->where($where)
        ->first();
     
        return Response()->json($book);
    }
     
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\book  $book
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $book = orders::where('id',$request->id)->delete();
     
        return Response()->json($book);
    }


    public function tesdiq(Request $request)
    {
        $con1 = orders::find($request->id);
        $products_id = $con1->product_id;
        $order_miqdar = $con1->miqdar;
        
        $con2 = products::find($products_id);
        $products_miqdar = $con2->miqdar;
        
        if($order_miqdar<=$products_miqdar){
      
            $netice = $products_miqdar - $order_miqdar;
            
            $con2->miqdar = $netice;
            $con2->save();

            $con1->tesdiq = 1;
            $con1->save();
        }
        return Response()->json($con1);
    }

    public function legv(Request $request)
    {
        $con1 = orders::find($request->id);
        $products_id = $con1->product_id;
        $order_miqdar = $con1->miqdar;
        
        $con2 = products::find($products_id);
        $products_miqdar = $con2->miqdar;

        $netice = $products_miqdar + $order_miqdar;
            
        $con2->miqdar = $netice;
        $con2->save();

        $con1->tesdiq = 0;
        $con1->save();
    
        return Response()->json($con1);
    }















    /*
    public function orders_ins(ordersRequest $post){

        date_default_timezone_set('Asia/Baku');
        $con = new orders();
        
        $con->tesdiq = 0;
        $con->clients_id = $post->ad;
        $con->product_id = $post->mehsul;
        $con->miqdar = $post->miqdar;
        $con->user_id = Auth::id();

        $con->save();

        return redirect()->route('orders')->with('success','Sifariş uğurla daxil edildi');
    }

    //Sifarişlerin ekrana verilmesi
    public function orders_list(){

        return view('orders',[
            
            'orders_data'=>orders::join('clients','clients.id','=','orders.clients_id')
            ->where('orders.user_id','=',Auth::id())
            ->join('products','products.id','=','orders.product_id')
            ->join('brands','brands.id','=','products.brands_id')
            ->select('orders.id','orders.miqdar as order_miqdar','orders.created_at','orders.tesdiq',
            'products.ad as mehsul','products.miqdar','products.foto','products.alis','products.user_id',
            'products.satis','brands.ad as brend','clients.ad as client','clients.soyad')
            ->orderby('id','desc')
            ->get(),
            
            'cdata'=>clients::orderbydesc('id')->with('orders')->where('user_id','=',Auth::id())->get(),
            'pdata'=>products::orderbydesc('id')->with('brands')->where('user_id','=',Auth::id())->get(),
            //'orders_data'=>orders::orderbydesc('id')->with('clients')->where('user_id','=',Auth::id())->get(),
            
            'total_client'=>clients::where('user_id','=',Auth::id())->count(),
            'total_brand'=>brands::where('user_id','=',Auth::id())->count(),
            'total_product'=>products::where('user_id','=',Auth::id())->count(),
            'total_order'=>orders::where('user_id','=',Auth::id())->count(),
        ]);
    }

    public function orders_delete($id){

        return view('orders',[
            //Orders siyahi
            'orders_data'=>orders::join('clients','clients.id','=','orders.clients_id')
            ->where('orders.user_id','=',Auth::id())
            ->join('products','products.id','=','orders.product_id')
            ->join('brands','brands.id','=','products.brands_id')
            ->select('orders.id','orders.miqdar as order_miqdar','orders.created_at','orders.tesdiq','products.ad as mehsul',
            'products.miqdar','products.alis','products.satis','products.foto','brands.ad as brend',
            'clients.ad as client','clients.soyad')
            ->orderby('id','desc')
            ->get(),

            'cdata'=>clients::orderbydesc('id')->with('orders')->where('user_id','=',Auth::id())->get(),
            'pdata'=>products::orderbydesc('id')->with('brands')->where('user_id','=',Auth::id())->get(),

            'sildata'=>orders::join('clients','clients.id','=','orders.clients_id')
            ->join('products','products.id','=','orders.product_id')
            ->join('brands','brands.id','=','products.brands_id')
            ->select('orders.id','orders.miqdar as order_miqdar','products.ad as mehsul',
            'products.miqdar','products.alis','products.satis','products.foto','brands.ad as brend',
            'clients.ad as client','clients.soyad')
            ->find($id),

            'total_client'=>clients::where('user_id','=',Auth::id())->count(),
            'total_brand'=>brands::where('user_id','=',Auth::id())->count(),
            'total_product'=>products::where('user_id','=',Auth::id())->count(),
            'total_order'=>orders::where('user_id','=',Auth::id())->count(),
        ]);
    }

    public function orders_sil($id){

        orders::find($id)->delete();
        return redirect()->route('orders')->with('success','Sifariş uğurla silindi');
    }

    public function orders_edit($id){

        return view('orders',[

            //Orders siyahi
            'orders_data'=>orders::join('clients','clients.id','=','orders.clients_id')
            ->where('orders.user_id','=',Auth::id())
            ->join('products','products.id','=','orders.product_id')
            ->join('brands','brands.id','=','products.brands_id')
            ->select('orders.id','orders.miqdar as order_miqdar','orders.created_at','orders.tesdiq','products.ad as mehsul',
            'products.miqdar','products.alis','products.satis','brands.ad as brend','products.foto','clients.ad as client','clients.soyad')
            ->orderby('id','desc')
            ->get(),

            'cdata'=>clients::orderbydesc('id')->with('orders')->where('user_id','=',Auth::id())->get(),
            'pdata'=>products::orderbydesc('id')->with('brands')->where('user_id','=',Auth::id())->get(),

            'editdata'=>orders::join('clients','clients.id','=','orders.clients_id')
            ->join('products','products.id','=','orders.product_id')
            ->join('brands','brands.id','=','products.brands_id')
            ->select('orders.id','orders.miqdar as order_miqdar','orders.clients_id','orders.product_id',
            'products.ad as mehsul','products.miqdar','products.alis','products.satis','brands.id as brands_id',
            'brands.ad as brend','clients.ad as client','clients.soyad')
            ->find($id),

            'total_client'=>clients::where('user_id','=',Auth::id())->count(),
            'total_brand'=>brands::where('user_id','=',Auth::id())->count(),
            'total_product'=>products::where('user_id','=',Auth::id())->count(),
            'total_order'=>orders::where('user_id','=',Auth::id())->count(),
        ]);
    }

    public function orders_update(ordersRequest $post){

        $edit = orders::find($post->id);

        $edit->clients_id = $post->ad;
        $edit->product_id = $post->mehsul;
        $edit->miqdar = $post->miqdar;

        $edit->save();

        return redirect()->route('orders')->with('success','Sifariş uğurla yeniləndi');
    }

    public function tesdiq($id){
       
        $con1 = orders::find($id);
        $products_id = $con1->product_id;
        $order_miqdar = $con1->miqdar;
        
        $con2 = products::find($products_id);
        $products_miqdar = $con2->miqdar;
        
        if($order_miqdar<=$products_miqdar){
      
            $netice = $products_miqdar - $order_miqdar;
            
            $con2->miqdar = $netice;
            $con2->save();

            $con1->tesdiq = 1;
            $con1->save();
    
            return redirect()->route('orders')->with('success','Sifariş uğurla təsdiq edildi');
        }
        else{
            return redirect()->route('orders')->with('fail','Anbarda kifayət qədər məhsul olmadiği üçün sifarişi təsdiq etmək mümkün olmadi');
        }
    }

    public function geri($id){

        $con1 = orders::find($id);
        $pid = $con1->product_id;
        $omiq = $con1->miqdar;

        $con2 = products::find($pid);
        $pmiq = $con2->miqdar;
            
        $netice = $pmiq + $omiq;

        $con2->miqdar = $netice;
        $con2->save();

        $con1->tesdiq = '0';
        $con1->save();

        return redirect()->route('orders'); 
    }

    public function export(){
        return Excel::download(new ordersExport,'Sifarişlərş.xlsx');
    }

    public function import(){
        Excel::download(new ordersImport,request()->file('file'));
        return back();
    }*/
}
