<?php

namespace App\Http\Controllers;

use Datatables;
use App\Models\brands;
use App\Models\orders;
use App\Models\clients;
use App\Models\products;
use Illuminate\Http\Request;
use App\Exports\clientsExport;
use App\Imports\clientsImport;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Facades\Excel;
use App\Http\Requests\clientsRequest;
use Illuminate\Support\Facades\Storage;

class clientsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(request()->ajax()) {
            return datatables()->of(clients::select('*')->where('user_id','=',Auth::id()))
            ->addColumn('action', 'book-action')
            ->addColumn('image', function($row){
                return $row->foto;
            })
            ->addColumn('created_at', function($row){
                return date('d-m-Y h:i:s', strtotime($row->created_at) );
            })
            ->addIndexColumn()
            ->make(true);
        }
        return view('clients',[

            //Toplam qazancin statistikasi
            'products_data'=>products::orderby('id','desc')
            ->join('brands','brands.id','=','products.brands_id')
            ->select('products.id','products.ad as mehsul','products.miqdar','products.alis',
            'products.satis','brands.ad as brend')
            ->where('products.user_id','=',Auth::id())
            ->get(),
            
            //Cari qazanc
            'orders_data'=>orders::join('clients','clients.id','=','orders.clients_id')
            ->join('products','products.id','=','orders.product_id')
            ->join('brands','brands.id','=','products.brands_id')
            ->select('orders.id','orders.miqdar as order_miqdar','orders.created_at','orders.tesdiq',
            'products.ad as mehsul','products.miqdar','products.foto','products.alis',
            'products.satis','brands.ad as brend','clients.ad as client','clients.soyad')
            ->where('orders.user_id','=',Auth::id())
            ->orderby('id','desc')
            ->get(),

            'total_client'=>clients::where('user_id','=',Auth::id())->count(),
            'total_brand'=>brands::where('user_id','=',Auth::id())->count(),
            'total_product'=>products::where('user_id','=',Auth::id())->count(),
            'total_order'=>orders::where('user_id','=',Auth::id())->count(),
        ]);
    }
     
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {  

        $bookId = $request->id;

        $con = new clients();
            
            if($bookId){
                
                $say = $con->where('tel','=',$request->tel)->where('id','!=',$bookId)
                ->orwhere('email','=',$request->email)->where('id','!=',$bookId)->count();

                $book = clients::find($bookId);

                if($request->hasFile('foto')){

                    $file = time().'.'.$request->foto->extension();
                    $request->foto->storeAS('uploads/clients/',$file);
                    $book ->foto = 'storage/app/uploads/clients/'.$file;
                }   
            }
            else
            {
                $say = $con->where('tel','=',$request->tel)->where('user_id','=',Auth::id())
                ->orwhere('email','=',$request->email)->where('user_id','=',Auth::id())->count();
                
                $book = new clients;
                
                $file = time().'.'.$request->foto->extension();
                $request->foto->storeAS('uploads/clients/',$file);
                $book ->foto = 'storage/app/uploads/clients/'.$file;
            }
        
        if($say == 0){
            
            date_default_timezone_set('Asia/Baku');
            
            $book->ad = $request->ad;
            $book->soyad = $request->soyad;
            $book->tel = $request->tel;
            $book->email = $request->email;
            $book->user_id = Auth::id();
            $book->save();
            
            return Response()->json($book);
        }
        return redirect()->back('clients');
    }
     
    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\book  $book
     * @return \Illuminate\Http\Response
     */
    public function edit(Request $request)
    {   
        $where = array('id' => $request->id);
        $book  = clients::where($where)->first();
        
        return Response()->json($book);
    }
     
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\book  $book
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $del = orders::where('clients_id','=',$request->id)->count();

        if($del == 0){
            $book = clients::where('id',$request->id)->delete();
            return Response()->json($book);
        }
        return redirect()->back('orders');
    }
















    
    /*
    public function clients_ins(clientsRequest $post){

        date_default_timezone_set('Asia/Baku');

        $con = new clients();

        $say = $con->where('tel','=',$post->tel)->orwhere('email','=',$post->email)->count();

        if($say == 0){ 

            $post->validate([
                'foto' => 'required|image|mimes:jpg,png,jpeg,gif,svg|max:2048',
            ]);

            if($post->file('foto')){
                $file = time().'.'.$post->foto->extension();
                $post->foto->storeAS('public/uploads/clients/',$file);
                $con ->foto = 'storage/uploads/clients/'.$file;
            } 
            else{
                $con -> foto = '';
            }

            $con->ad = $post->ad;
            $con->soyad = $post->soyad;
            $con->tel = $post->tel;
            $con->email = $post->email;
            
            $con->user_id = Auth::id();

            $con->save();

            return redirect()->route('clients')->with('success','Müştəri uğurla bazaya əlavə edildi');
        }
        return redirect()->route('clients')->with('fail','Daxil etdiyiniz müştəri bazada mövcuddur');
    }

    public function clients_list(){
        
        return view('clients',[
            'client_data'=>clients::orderby('id','desc')->where('user_id','=',Auth::id())->get(),

            //Toplam qazancin statistikasi
            'products_data'=>products::orderby('id','desc')
            ->join('brands','brands.id','=','products.brands_id')
            ->select('products.id','products.ad as mehsul','products.miqdar','products.alis',
            'products.satis','brands.ad as brend')
            ->where('products.user_id','=',Auth::id())
            ->get(),

            //Cari qazanc
            'orders_data'=>orders::join('clients','clients.id','=','orders.clients_id')
            ->join('products','products.id','=','orders.product_id')
            ->join('brands','brands.id','=','products.brands_id')
            ->select('orders.id','orders.miqdar as order_miqdar','orders.created_at','orders.tesdiq',
            'products.ad as mehsul','products.miqdar','products.foto','products.alis',
            'products.satis','brands.ad as brend','clients.ad as client','clients.soyad')
            ->where('orders.user_id','=',Auth::id())
            ->orderby('id','desc')
            ->get(),

            'total_client'=>clients::where('user_id','=',Auth::id())->count(),
            'total_brand'=>brands::where('user_id','=',Auth::id())->count(),
            'total_product'=>products::where('user_id','=',Auth::id())->count(),
            'total_order'=>orders::where('user_id','=',Auth::id())->count(),
        ]);
    }

    public function clients_delete($id){

        return view('clients',[
            'client_data'=>clients::orderby('id','desc')->where('user_id','=',Auth::id())->get(),

            'sildata'=>clients::find($id),

            //Toplam qazancin statistikasi
            'products_data'=>products::orderby('id','desc')
            ->join('brands','brands.id','=','products.brands_id')
            ->select('products.id','products.ad as mehsul','products.miqdar','products.alis',
            'products.satis','brands.ad as brend')
            ->where('products.user_id','=',Auth::id())
            ->get(),

            //Cari qazanc
            'orders_data'=>orders::join('clients','clients.id','=','orders.clients_id')
            ->join('produts','products.id','=','orders.product_id')
            ->join('brands','brands.id','=','products.brands_id')
            ->select('orders.id','orders.miqdar as order_miqdar','orders.created_at','orders.tesdiq',
            'products.ad as mehsul','products.miqdar','products.foto','products.alis',
            'products.satis','brands.ad as brend','clients.ad as client','clients.soyad')
            ->where('orders.user_id','=',Auth::id())
            ->orderby('id','desc')
            ->get(),
            
            'total_client'=>clients::where('user_id','=',Auth::id())->count(),
            'total_brand'=>brands::where('user_id','=',Auth::id())->count(),
            'total_product'=>products::where('user_id','=',Auth::id())->count(),
            'total_order'=>orders::where('user_id','=',Auth::id())->count(),
        ]);
    }

    public function clients_sil($id){

        clients::find($id)->delete();
        return redirect()->route('clients')->with('success','Müştəri uğurla silindi');
    }

    public function clients_edit($id){
        
        return view('clients',[

            'client_data'=>clients::orderby('id','desc')->where('user_id','=',Auth::id())->get(),

            'editdata'=>clients::find($id),

            //Toplam qazancin statistikasi
            'products_data'=>products::orderby('id','desc')
            ->join('brands','brands.id','=','products.brands_id')
            ->select('products.id','products.ad as mehsul','products.miqdar','products.alis',
            'products.satis','brands.ad as brend')
            ->where('products.user_id','=',Auth::id())
            ->get(),

            //Cari qazanc
            'orders_data'=>orders::join('clients','clients.id','=','orders.clients_id')
            ->join('products','products.id','=','orders.product_id')
            ->join('brands','brands.id','=','products.brands_id')
            ->select('orders.id','orders.miqdar as order_miqdar','orders.created_at','orders.tesdiq',
            'products.ad as mehsul','products.miqdar','products.foto','products.alis',
            'products.satis','brands.ad as brend','clients.ad as client','clients.soyad')
            ->where('orders.user_id','=',Auth::id())
            ->orderby('id','desc')
            ->get(),

            'total_client'=>clients::where('user_id','=',Auth::id())->count(),
            'total_brand'=>brands::where('user_id','=',Auth::id())->count(),
            'total_product'=>products::where('user_id','=',Auth::id())->count(),
            'total_order'=>orders::where('user_id','=',Auth::id())->count(),
        ]);
    }

    public function clients_update(clientsRequest $post){
        
        $con = new clients();

        $say = $con->where('tel','=',$post->tel)->where('id','!=',$post->id)->count();

        $edit = clients::find($post->id);

        if($post->file('foto')){

            $post->validate([
                'foto' => 'required|image|mimes:jpg,png,jpeg,gif,svg|max:2048',
            ]);

            $file = time().'.'.$post->foto->extension();
            $post->foto->storeAS('public/uploads/clients/',$file);
            $edit ->foto = 'storage/uploads/clients/'.$file;
        } 
        else{
            $edit -> foto = $post->carifoto;
        }

        if($say == 0){

            $edit->ad = $post->ad;
            $edit->soyad = $post->soyad;
            $edit->tel = $post->tel;
            $edit->email = $post->email;

            $edit->save();

            return redirect()->route('clients')->with('success','Müştəri uğurla yeniləndi');
        }
        return redirect()->route('clients')->with('fail','Bu müştəri bazada mövcuddur');        
    }

    public function export(){
        return Excel::download(new clientsExport,'Müştərilər.xlsx');
    }

    public function import(){
        Excel::download(new clientsImport, request()->file('file'));

        return back();
    }*/
}
