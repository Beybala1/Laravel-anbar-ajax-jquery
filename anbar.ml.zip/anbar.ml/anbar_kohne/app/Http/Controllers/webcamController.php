<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Stroage;

class webcamController extends Controller
{
    public function index(){
        return view('clients');
    }
    public function storage(Request $post){
        $image = $post->image;
        $papka = 'uploads/';
        $image_parts = explode(';base64',$image);
        $image_type = explode('images/',$image_parts[0]);
        $type = $image_type[1];
        $image_base64 = base64_decode($image_parts[1]);
        $filename = uniqid().'.png';
        $file = $papka.$filename;
        Storage::put($file,$image_base64);

        dd('Foto uğurla yükləndi: '.$filename);
    }
}
