<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class ordersRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'ad'=>'required',
            'mehsul'=>'required',
            'miqdar'=>'required|min:1|max:15',
        ];
    }

    public function messages()
    {
        return [
            'ad.required'=>'Ad daxil etmədiniz',

            'mehsul.required'=>'Məhsul daxil etmədiniz',

            'miqdar.required'=>'Miqdar daxil etmədiniz', 'miqdar.min'=>'Miqdar minimum 1 simvol olmalidir',
            'miqdar.max'=>'Miqdar maximum 15 simvol olmalidir',             
        ];
    }
}
