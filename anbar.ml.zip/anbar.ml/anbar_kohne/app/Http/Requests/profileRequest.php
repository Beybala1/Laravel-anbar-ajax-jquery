<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class profileRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'ad'=>'min:3|max:15',
            'email'=>'min:3|max:30',
            //'cari_parol'=>'min:3|max:30',
        ];
    }

    public function messages()
    {
        return [
            'ad.min'=>'İstifadəçi xanasi minimum 3 simvol olmalidir','ad.max'=>'İstifadəçi xanasi maximum 15 simvol olmalidir', 
            
            'email.min'=>'Email minimum 3 simvol olmalidir','email.max'=>'Email maximum 15 simvol olmalidir',

            //'cari_parol.min'=>'Parol minimum 3 simvol olmalidir','cari_parol.max'=>'Parol maximum 15 simvol olmalidir',
        ];
    }
}
