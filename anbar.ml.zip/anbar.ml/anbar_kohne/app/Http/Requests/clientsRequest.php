<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class clientsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'ad'=>'required|min:3|max:15',
            'soyad'=>'required|min:3|max:15',
            'tel'=>'required|min:3|max:15',
            'email'=>'required|min:3',
        ];
    }

    public function messages()
    {
        return [
            'ad.required'=>'Ad xanasini boş buraxmayin','ad.min'=>'Ad minimum 3 simvol olmalidir',
            'ad.max'=>'Ad maximum 15 simvol olmalidir',

            'soyad.required'=>'Soyad xanasini boş buraxmayin','soyad.min'=>'Soyad minimum 3 simvol olmalidir',
            'soyad.max'=>'Soyad maximum 15 simvol olmalidir',

            'tel.required'=>'Telefon xanasini boş buraxmayin','tel.min'=>'Telefon minimum 3 simvol olmalidir',
            'tel.max'=>'Telefon maximum 15 simvol olmalidir',

            'email.required'=>'Email xanasini boş buraxmayin','email.min'=>'Email minimum 3 simvol olmalidir',
        ];
    }
}
