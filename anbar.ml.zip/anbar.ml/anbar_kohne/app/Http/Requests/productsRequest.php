<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class productsRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(){
        return [
            'ad'=>'required|min:3|max:15',
            'brend_id'=>'required',
            'alis'=>'required|',
            'satis'=>'required',
            'miqdar'=>'required',
        ];
    }

    public function messages()
    {
        return [
            'ad.required'=>'Məhsul daxil etmediniz', 'ad.min'=>'Məhsul minimum 3 simvol olmalidir',
            'ad.max'=>'Məhsul maximum 15 simvol olmalidir', 

            'brend_id.required'=>'Zəhmət olmasa brend seçimi edin',

            'alis.required'=>'Aliş qiyməti daxil etmədiniz', 'alis.max'=>'Qiymət maximum 15 simvol olmalidir',
            
            'satis.required'=>'Satis qiyməti daxil etmədiniz', 'satis.max'=>'Qiymet maximum 15 simvol olmalidir', 
              
            'miqdar.required'=>'Miqdar daxil etmədiniz', 'miqdar.max'=>'Miqdar maximum 15 simvol olmalidir',
        ];
    }
}
