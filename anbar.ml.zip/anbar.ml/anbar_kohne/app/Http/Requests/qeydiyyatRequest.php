<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class qeydiyyatRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */

    public function rules()
    {
        return [
            'ad'=>'required|min:3|max:15',
            'email'=>'required|min:3',
            'parol'=>'required|min:3',
            'parol_t'=>'required|min:3',
        ];
    }

    public function messages()
    {
        return [
            'ad.required'=>'İstifadəçi xanasini boş buraxmayin','ad.min'=>'Ad minimum 3 simvol olmalidir',
            'ad.max'=>'Ad maximum 15 simvol olmalidir',
            
            'email.required'=>'Email xanasini boş buraxmayin','email.min'=>'Email minimum 3 simvol olmalidir',

            'parol.required'=>'Parol xanasini boş buraxmayin','parol.min'=>'Parol minimum 3 simvol olmalidir',

            'parol_t.required'=>'Təkrar parol xanasini boş buraxmayin','parol_t.min'=>'Təkrar parol minimum 3 simvol olmalidir',
        ];
    }
}
