<?php

namespace App\Exports;

use App\Models\products;
use Maatwebsite\Excel\Concerns\FromCollection;

class productsExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return products::select('ad','alis','satis','miqdar','created_at')->get();
    }

    public function headings():array{
        return ['Ad','Aliş','Satiş','Miqdar','Tarix'];
    }
}
