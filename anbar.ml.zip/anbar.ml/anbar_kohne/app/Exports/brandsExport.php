<?php

namespace App\Exports;

use App\Models\brands;
use Maatwebsite\Excel\Concerns\FromCollection;

class brandsExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return brands::select('ad','created_at')->get();
    }
    
    public function headings():array{
        return['Ad','Tarix'];
    }
}
