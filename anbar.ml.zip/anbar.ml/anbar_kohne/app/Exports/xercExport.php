<?php

namespace App\Exports;

use App\Models\xerc;
use Maatwebsite\Excel\Concerns\FromCollection;

class xercExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return xerc::select('ad','qiymet','created_at')->get();
    }

    public function headings():array{
        return['Ad','Qiymət','Tarix'];
    }
}
