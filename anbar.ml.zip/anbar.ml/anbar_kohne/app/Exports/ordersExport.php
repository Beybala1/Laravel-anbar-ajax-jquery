<?php

namespace App\Exports;

use App\Models\orders;
use App\Models\brands;
use App\Models\clients;
use App\Models\products;
use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Concerns\FromCollection;


class ordersExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return orders::join('clients','clients.id','=','orders.clients_id')
        ->where('orders.user_id','=',Auth::id())
        ->join('products','products.id','=','orders.product_id')
        ->join('brands','brands.id','=','products.brands_id')
        ->select('orders.id','orders.miqdar as order_miqdar','orders.created_at','orders.tesdiq',
        'products.ad as mehsul','products.miqdar','products.foto','products.alis','products.user_id',
        'products.satis','brands.ad as brend','clients.ad as client','clients.soyad')
        ->orderby('id','desc')
        ->get();
    }

    public function headings():array{
        return ['Müştəri','Məhsul','Brend','Məhsul miqdar','Sifariş miqdar','Tarix'];
    }
}
