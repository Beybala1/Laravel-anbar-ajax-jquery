<?php

namespace App\Exports;

use App\Models\clients;
use Maatwebsite\Excel\Concerns\FromCollection;

class clientsExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return clients::select('ad','soyad','tel','email','foto','created_at')->get();
    }
    
    public function headings():array{
        return ['Ad','Soyad','Telefon','Email','Tarix','Foto','Tarix'];
    }
}
