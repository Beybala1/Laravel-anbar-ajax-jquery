<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class clients extends Model
{
    use HasFactory;

    public function orders(){
        return $this->hasMany(orders::class);
    }

    protected $fillable = [
        'ad', 'foto', 'user_id'
    ];
}
