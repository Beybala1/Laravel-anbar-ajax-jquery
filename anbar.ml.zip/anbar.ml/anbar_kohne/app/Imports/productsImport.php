<?php

namespace App\Imports;

use App\Models\products;
use Maatwebsite\Excel\Concerns\ToModel;

class productsImport implements ToModel
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new products([
            'ad'=>$row['ad'],
            'alis'=>$row['alis'],
            'satis'=>$row['satis'],
            'miqdar'=>$row['miqdar'],
            'foto'=>$row['foto'],
        ]);
    }
}
