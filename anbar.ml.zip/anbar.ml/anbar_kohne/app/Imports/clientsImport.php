<?php

namespace App\Imports;

use App\Models\clients;
use Maatwebsite\Excel\Concerns\ToModel;

class clientsImport implements ToModel
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new clients([
            'name'=>$row['ad'],
            'lastname'=>$row['soyad'],
            'telefon'=>$row['tel'],
            'email'=>$row['email'],
            'foto'=>$row['foto'],
            'tarix'=>$row['created_at']
        ]);
    }
}
