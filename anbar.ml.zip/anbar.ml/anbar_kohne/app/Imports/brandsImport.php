<?php

namespace App\Imports;

use App\Models\brands;
use Maatwebsite\Excel\Concerns\ToModel;

class brandsImport implements ToModel
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new brands([
            'name'=>$row['ad'],
            'tarix'=>$row['created_at']
        ]);
    }
}
