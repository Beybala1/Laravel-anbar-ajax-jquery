  <!-- partial:partials/_sidebar.html -->
  <nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link" href="http://127.0.0.1:8000/">
          <ion-icon size="large" name="people-outline"></ion-icon>
          <span style="margin: 0 30px" class="menu-title">Müştəri</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="http://127.0.0.1:8000/brands">
          <ion-icon size="large" name="bookmark-outline"></ion-icon>
          <span style="margin: 0 30px" class="menu-title">Brend</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="http://127.0.0.1:8000/xerc">
          <ion-icon size="large" name="reader-outline"></ion-icon>
          <span style="margin: 0 30px" class="menu-title">Xərc</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="http://127.0.0.1:8000/products">
          <ion-icon size="large" name="shirt-outline"></ion-icon>
          <span style="margin: 0 30px" class="menu-title">Məhsul</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="http://127.0.0.1:8000/orders">
          <ion-icon size="large" name="bag-handle-outline"></ion-icon>
          <span style="margin: 0 30px" class="menu-title">Sifariş</span>
        </a>
      </li>
      
      <li class="nav-item">
        <a class="nav-link" data-toggle="collapse" href="#auth" aria-expanded="false" aria-controls="auth">
          <ion-icon size="large" name="person-outline"></ion-icon>
          <span style="margin: 0 30px" class="menu-title">Profil</span>
          <i style="margin: 0 -5px" class="menu-arrow"></i>
        </a>
        <div class="collapse" id="auth">
          <ul class="nav flex-column sub-menu">
            <li class="nav-item"> <a class="nav-link" href="http://127.0.0.1:8000/login"> Giriş </a></li>
            <li class="nav-item"> <a class="nav-link" href="http://127.0.0.1:8000/qeydiyyat"> Qeydiyyat </a></li>
          </ul>
        </div>
      </li>
  </nav>
  <!-- partial --><?php /**PATH C:\xampp\htdocs\anbar\resources\views/inc/sidebar.blade.php ENDPATH**/ ?>