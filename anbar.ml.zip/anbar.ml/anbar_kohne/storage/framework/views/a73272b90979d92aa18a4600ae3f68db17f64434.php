

<?php $__env->startSection('xerc'); ?>
<html lang="az-AZ">
<head>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" 
  integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
 
          <div class="col-12 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                <h4 class="card-title">Xərc formu</h4>

                <?php if(session('success')): ?>
                  <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?><br><br>
                  </div>                                        
                <?php endif; ?>

                <?php if($errors->any): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sehv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger" role="alert">
                      <?php echo e($sehv); ?><br><br>
                    </div>                     
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php if(isset($sildata)): ?>
                    Siz <?php echo e($sildata->ad); ?> xərcini silmək istəyirsinizmi?<br>
                    <a href=<?php echo e(route('xerc_sil',$sildata->id)); ?>><button type="button" class="btn btn-danger">Sil</button></a>
                    <a href=<?php echo e(route('xerc')); ?>><button type="button" class="btn btn-info">Ləğv et</button></a>                 
                <?php endif; ?>

                <?php if(empty($editdata)): ?>
                    <form class="forms-sample" method="post" action="<?php echo e(route('xerc_ins')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputName1">Ad</label>
                        <input type="text" class="form-control" name="ad" id="exampleInputName1" placeholder="Ad">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputName1">Qiymət</label>
                        <input type="number" class="form-control" name="qiymet" id="exampleInputName1" placeholder="Qiymət">
                    </div>
                    <button type="submit" class="btn btn-primary mr-2">Daxil et</button>
                    <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                <?php endif; ?>

                <?php if(isset($editdata)): ?>
                    <form class="forms-sample" method="post" action="<?php echo e(route('xerc_update')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputName1">Ad</label>
                        <input type="text" class="form-control" name="ad" value="<?php echo e($editdata->ad); ?>" id="exampleInputName1" placeholder="Ad">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputName1">Qiymət</label>
                        <input type="number" class="form-control" name="qiymet" value="<?php echo e($editdata->qiymet); ?>" id="exampleInputName1" placeholder="Qiymət">
                    </div>
                    <input type="hidden" name="id" value="<?php echo e($editdata->id); ?>">
                    <button type="submit" class="btn btn-success mr-2">Yenilə</button>
                    <a href="<?php echo e(route('xerc')); ?>"><button type="button" class="btn btn-warning mr-2">Ləğv et</button></a>
                    <!--<button class="btn btn-light">Cancel</button>-->
                    </form>
                <?php endif; ?>
              </div>
            </div>
          </div>
          
          <?php ($alis = 0); ?>
          <?php ($satis = 0); ?>
          <?php ($miqdar = 0); ?>
          <?php ($qazanc = 0); ?>

          <?php $__currentLoopData = $products_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php ($qazanc = ($p->satis - $p->alis)*$p->miqdar); ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
          <?php ($cqazanc = 0); ?>
          <?php $__currentLoopData = $orders_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_qazanc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($order_qazanc->tesdiq==1): ?>
              <?php ($cqazanc = ($order_qazanc->satis - $order_qazanc->alis)*$order_qazanc->order_miqdar); ?>
            <?php endif; ?>           
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <div class="col-lg-12 grid-margin stretch-card">
            <div class="table-responsive pt-3">
              <table class="table table-dark">
                <a href="<?php echo e(route('xercExport')); ?>">
                  <img target="_blank" src="https://img.icons8.com/color/48/000000/ms-excel.png"/>
                  Xərclər
                </a>
                <thead>
                  <tr>
                    <th>#</th>
                    <th>Məhsul</th>
                    <th>Qiymət</th>
                    <th>Tarix</th>
                    <th></th>
                  </tr>  
                </thead>       
                <tbody>      
                    <?php $__currentLoopData = $xerc_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr> 
                        <td><?php echo e($i+=1); ?></td>
                        <td><?php echo e($info->ad); ?></td>  
                        <td><?php echo e($info->qiymet); ?></td> 
                        <td><?php echo e($info->created_at); ?></td>  
                        <td>
                          <a href=<?php echo e(route('xerc_delete',$info->id)); ?>><button style="margin:0 -35px;" class="btn btn-danger btn-sm">
                          <ion-icon name="trash"></ion-icon></button></a>
                        </td>
                        <td>
                          <a href=<?php echo e(route('xerc_edit',$info->id)); ?>><button style="margin:0 -30px;" class="btn btn-primary btn-sm">
                          <ion-icon name="create"></ion-icon></button></a>
                        </td>
                      </tr>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
                </tbody>
              </table>
            </div>
          </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Müəllif hüquqlari qorunur 2022</span>
          </div>
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Beybala Muxtarov <a href="http://127.0.0.1:8000/" target="_blank">Anbar</a></span> 
          </div>
        </footer> 
        <!-- partial -->

    <!-- plugins:js -->
    <script src="<?php echo e(url('vendors/js/vendor.bundle.base.js')); ?>"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="<?php echo e(url('vendors/chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(url('vendors/datatables.net/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(url('vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
    <script src="<?php echo e(url('js/dataTables.select.min.js')); ?>"></script>

    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="<?php echo e(url('js/off-canvas.js')); ?>"></script>
    <script src="<?php echo e(url('js/settings.js')); ?>"></script>
    <script src="<?php echo e(url('js/todolist.js')); ?>"></script>
    <!-- endinject -->
    <!-- Custom js for this page-->
    <script src="<?php echo e(url('js/dashboard.js')); ?>"></script>
    <script src="<?php echo e(url('js/Chart.roundedBarCharts.js')); ?>"></script>
    <!-- End custom js for this page-->
  </body>
  </html>
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\anbar\resources\views/xerc.blade.php ENDPATH**/ ?>