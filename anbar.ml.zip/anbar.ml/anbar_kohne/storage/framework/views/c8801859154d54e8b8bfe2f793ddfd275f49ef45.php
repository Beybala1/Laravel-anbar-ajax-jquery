<?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('inc.statistika', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('clients'); ?>
<?php echo $__env->yieldContent('brands'); ?>
<?php echo $__env->yieldContent('xerc'); ?>
<?php echo $__env->yieldContent('products'); ?>
<?php echo $__env->yieldContent('orders'); ?>
<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\anbar\resources\views/layouts/app.blade.php ENDPATH**/ ?>