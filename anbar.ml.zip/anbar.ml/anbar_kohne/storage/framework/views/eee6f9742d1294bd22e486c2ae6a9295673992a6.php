<div class="container-scroller">
    <?php echo $__env->make('inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container-fluid page-body-wrapper">
        <?php echo $__env->make('inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('inc.statistika', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('clients'); ?>
        <?php echo $__env->yieldContent('brands'); ?>
        <?php echo $__env->yieldContent('xerc'); ?>
        <?php echo $__env->yieldContent('products'); ?>
        <?php echo $__env->yieldContent('orders'); ?>
        <?php echo $__env->yieldContent('myprofile'); ?>
        <?php echo $__env->yieldContent('employee'); ?>
        <?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<script src="<?php echo e(url('vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
<script src="<?php echo e(url('js/dataTables.select.min.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0/dist/Chart.min.js"></script>
<!-- End plugin js for this page -->
<!-- inject:js -->
<script src="<?php echo e(url('js/off-canvas.js')); ?>"></script>
<script src="<?php echo e(url('js/settings.js')); ?>"></script>
<script src="<?php echo e(url('js/todolist.js')); ?>"></script>
<!-- endinject -->
<!-- Custom js for this page-->
<script src="<?php echo e(url('js/dashboard.js')); ?>"></script>
<script src="<?php echo e(url('../../js/file-upload.js')); ?>"></script><?php /**PATH /home/filmbaxt/anbar.ml/resources/views/layouts/app.blade.php ENDPATH**/ ?>