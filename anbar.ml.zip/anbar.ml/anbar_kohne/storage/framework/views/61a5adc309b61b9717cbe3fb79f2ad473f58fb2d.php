
<a href="javascript:void(0);" id="delete-book" data-toggle="tooltip" data-original-title="Delete" data-id="<?php echo e($id); ?>" class="delete btn btn-danger">
   <ion-icon name="trash"></ion-icon>
</a>

<a href="javascript:void(0)" data-toggle="tooltip"  data-id="<?php echo e($id); ?>" data-original-title="Edit" class="edit btn btn-success edit">
   <ion-icon name="create"></ion-icon>
</a>
<?php /**PATH /home/filmbaxt/anbar.ml/resources/views/book-action.blade.php ENDPATH**/ ?>