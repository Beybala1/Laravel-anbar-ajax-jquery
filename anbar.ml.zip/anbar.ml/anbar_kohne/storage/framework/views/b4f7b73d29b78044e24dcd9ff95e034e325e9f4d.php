;

<?php $__env->startSection('myprofile'); ?>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">  
<link  href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

<div class="col-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <h2 class="card-title">Profil</h2>

            <?php if($errors->any): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sehv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger" role="alert">
                        <?php echo e($sehv); ?><br><br>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?><br><br>
                </div>
            <?php endif; ?>

            <?php if(session('fail')): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(session('fail')); ?><br><br>
                </div>
            <?php endif; ?>

            <form class="forms-sample" method="post" action="<?php echo e(url('myprofile_ins')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <label>Foto</label>
                <div class="col-sm-13">
                    <input type="file"  class="form-control" id="image" name="foto" value="<?php echo e(Auth::user()->foto); ?>">
                    <input type="hidden" name="carifoto" value="<?php echo e(Auth::user()->foto); ?>">
                    <img src="<?php echo e(url(Auth::user()->foto)); ?>">                
                </div>
            
                <div class="form-group">
                    <label for="exampleInputName1">Ad</label>
                    <input type="text" class="form-control" name="ad" value="<?php echo e(Auth::user()->name); ?>" id="exampleInputName1" placeholder="Ad" required="">
                </div>

                <div class="form-group">
                    <label for="exampleInputName1">Email</label>
                    <input type="email" class="form-control" name="email" value="<?php echo e(Auth::user()->email); ?>" id="exampleInputName1" placeholder="Email" required="">
                </div>

                <div class="form-group">
                    <label for="exampleInputName1">Cari parol</label>
                    <input type="password" class="form-control" name="cari_parol" id="exampleInputName1" placeholder="Cari parol" required="">
                </div>

                <div class="form-group">
                    <label for="exampleInputName1">Yeni parol</label>
                    <input type="password" class="form-control" name="yeni_parol" id="exampleInputName1" placeholder="Yeni parol">
                </div>

                <div class="form-group">
                    <label for="exampleInputName1">Təkrar parol</label>
                    <input type="password" class="form-control" name="parol_t" id="exampleInputName1" placeholder="Təkrar parol">
                </div>
                <button type="submit" class="btn btn-primary mr-2">Yenilə</button>
                <!--<button class="btn btn-light">Cancel</button>-->
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/filmbaxt/anbar.ml/resources/views/myprofile.blade.php ENDPATH**/ ?>