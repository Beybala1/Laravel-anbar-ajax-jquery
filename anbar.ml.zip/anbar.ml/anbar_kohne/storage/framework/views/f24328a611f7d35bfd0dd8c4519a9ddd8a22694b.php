<div class="main-panel">
    <div class="content-wrapper">
      <div class="row">
        <div class="col-md-12 grid-margin transparent">
          <div class="row"> 
            <div class="col-md-2 mb-4 mb-lg-0 stretch-card transparent">
              <div class="card card-tale">
                <a style="text-decoration:none; color:white;" href="http://127.0.0.1:8000/">
                  <div class="card-body">
                    <p class="mb-4">Toplam müştəri</p>
                    <p class="fs-30 mb-2"><?php echo e($total_client); ?></p>
                  </div>
                </a>
              </div>
            </div>
            <div class="col-md-2 mb-4 mb-lg-0 stretch-card transparent">
              <div class="card card-dark-blue">
                <a style="text-decoration:none; color:white;" href="http://127.0.0.1:8000/brands">
                  <div class="card-body">
                    <p class="mb-4">Toplam brend</p>
                    <p class="fs-30 mb-2"><?php echo e($total_brand); ?></p>
                  </div>
                </a>
              </div>
            </div>
            <div class="col-md-2 mb-4 mb-lg-0 stretch-card transparent">
              <div class="card card-light-blue">
                <a style="text-decoration:none; color:white;" href="http://127.0.0.1:8000/products">
                  <div class="card-body">
                    <p class="mb-4">Toplam məhsul</p>
                    <p class="fs-30 mb-2"><?php echo e($total_product); ?></p>
                  </div>
                </a>
              </div>
            </div>
            <div class="col-md-2 stretch-card transparent">
              <div class="card card-light-danger">
                <a style="text-decoration:none; color:white;" href="http://127.0.0.1:8000/orders">
                  <div class="card-body">
                    <p class="mb-4">Toplam sifariş</p>
                    <p class="fs-30 mb-2"><?php echo e($total_order); ?></p>
                  </div>
                </a>
              </div>
            </div>
            <div class="col-md-2 stretch-card transparent">
              <div class="card card-light-danger">
                <a style="text-decoration:none; color:white;" href="http://127.0.0.1:8000/orders">
                  <div class="card-body">
                    <p class="mb-4">Toplam qazanc</p>
                    <p class="fs-30 mb-2"><?php echo e($qazanc); ?></p>
                  </div>
                </a>
              </div>
            </div>
            <div class="col-md-2 stretch-card transparent">
              <div class="card card-light-danger">
                <a style="text-decoration:none; color:white;" href="http://127.0.0.1:8000/orders">
                  <div class="card-body">
                    <p class="mb-4">Cari qazanc</p>
                    <p class="fs-30 mb-2"><?php echo e($cqazanc); ?></p>
                  </div>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      
<?php /**PATH C:\xampp\htdocs\anbar\resources\views/inc/statistika.blade.php ENDPATH**/ ?>