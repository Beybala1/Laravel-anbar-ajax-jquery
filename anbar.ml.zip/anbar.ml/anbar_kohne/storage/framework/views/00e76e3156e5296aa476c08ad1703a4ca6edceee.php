

<?php $__env->startSection('products'); ?>
<html lang="az-AZ">
<head>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">  
  <link  href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

  <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/dataTables.buttons.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.html5.min.js"></script>
  <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/2.2.3/js/buttons.print.min.js"></script>
</head>
                <body> 
                  <div class="container mt-4">
                  <div class="col-md-12 mt-1 mb-2"><button style="margin: 0 -13px" type="button" id="addNewBook" class="btn btn-success">Daxil et</button></div>
                  <div class="card">
                    <div class="card-header text-center font-weight-bold">
                      <h2>Məhsul cədvəli</h2>
                    </div>
                    <div class="col-lg-12 grid-margin stretch-card">
                      <div class="table-responsive pt-3">
                        <div class="card-body">
                          <table class="table table-bordered" id="datatable-ajax-crud">
                            <thead>
                              <tr>
                                <th>#</th>
                                <th>Foto</th>
                                <th>Məhsul</th>
                                <th>Brend</th>
                                <th>Aliş</th>
                                <th>Satiş</th>
                                <th>Miqdar</th>
                                <th>Tarix</th>
                                <th>Əməliyyatlar</th>
                              </tr>
                            </thead>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>

                  <?php ($alis = 0); ?>
                  <?php ($satis = 0); ?>
                  <?php ($miqdar = 0); ?>
                  <?php ($qazanc = 0); ?>
                
                  <?php $__currentLoopData = $products_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php ($qazanc = ($p->satis - $p->alis)*$p->miqdar); ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                  <?php ($cqazanc = 0); ?>
                  
                  <?php $__currentLoopData = $orders_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order_qazanc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($order_qazanc->tesdiq==1): ?>
                      <?php ($cqazanc = ($order_qazanc->satis - $order_qazanc->alis)*$order_qazanc->order_miqdar); ?>
                    <?php endif; ?>           
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  <!-- boostrap add and edit book model -->
                    <div class="modal fade" id="ajax-book-model" aria-hidden="true">
                      <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h4 class="modal-title" id="ajaxBookModel"></h4>
                          </div>
                          <div class="modal-body">
                            <form action="javascript:void(0)" id="addEditBookForm" name="addEditBookForm" class="form-horizontal" method="POST" enctype="multipart/form-data">
                              <input type="hidden" name="id" id="id">

                              <div class="form-group">
                                <label for="name" class="col-sm-2 control-label">Ad</label>
                                <div class="col-sm-12">
                                  <input type="text" class="form-control" id="ad" name="ad" placeholder="Məhsul" maxlength="50" required="">
                                </div>
                              </div>

                              <?php if(empty($editdata)): ?>
                                <div class="form-group">
                                  <label for="name" class="col-sm-2 control-label">Brend</label>
                                  <div class="col-sm-12">
                                    <select id="brend_id" name="brend_id" class="form-control" required="">
                                      <option selected value="">Brend seçin</option>
                                      <?php $__currentLoopData = $brand_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                        <option value="<?php echo e($brand->brands->id); ?>"><?php echo e($brand->brands->ad); ?></option>
                                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                    
                                    </select>
                                  </div>
                                </div> 
                              <?php endif; ?>

                              <?php if(isset($editdata)): ?>
                                <div class="form-group">
                                  <label for="name" class="col-sm-2 control-label">Brend</label>
                                  <div class="col-sm-12">
                                    <select id="brend_id" name="brend_id" class="form-control" required="">
                                      <option value="">Brend seçin</option>
                                        <?php $__currentLoopData = $brand_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                          <?php if($editdata->brands->id == $editdata->products->brands_id ): ?>
                                            <option selected value="<?php echo e($brand->brands->id); ?>"><?php echo e($brand->brands->ad); ?></option> 
                                          <?php else: ?>
                                          <option value="<?php echo e($brand->brands->id); ?>"><?php echo e($brand->brands->ad); ?></option>
                                          <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                  </div>
                                </div> 
                              <?php endif; ?>
                
                              <div class="form-group">
                                <label for="name" class="col-sm-2 control-label">Aliş</label>
                                <div class="col-sm-12">
                                  <input type="number" class="form-control" id="alis" name="alis" placeholder="Aliş" maxlength="50" required="">
                                </div>
                              </div>
                
                              <div class="form-group">
                                <label for="name" class="col-sm-2 control-label">Satiş</label>
                                <div class="col-sm-12">
                                  <input type="number" class="form-control" id="satis" name="satis" placeholder="Satiş" maxlength="50" required="">
                                </div>
                              </div>   
                              
                              <div class="form-group">
                                <label for="name" class="col-sm-2 control-label">Miqdar</label>
                                <div class="col-sm-12">
                                  <input type="number" class="form-control" id="miqdar" name="miqdar" placeholder="Miqdar" maxlength="50" required="">
                                </div>
                              </div>
                
                               <div class="form-group">
                                <label class="col-sm-2 control-label">Foto</label>
                                <div class="col-sm-6 pull-left">
                                  <input type="file" class="form-control" id="image" name="foto" required="">
                                </div>               
                                <div class="col-sm-6 pull-right">
                                  <img id="preview-image" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSM4sEG5g9GFcy4SUxbzWNzUTf1jMISTDZrTw&usqp=CAU"
                                    alt="preview image" style="max-height: 250px;">
                                </div>
                              </div>
                
                              <div class="col-sm-offset-2 col-sm-10">
                                <button type="submit" class="btn btn-primary" id="btn-save" value="addNewBook">Daxil et</button>
                              </div>
                            </form>
                          </div>
                          <div class="modal-footer">
                          </div>
                        </div>
                      </div>
                    </div>
                <!-- end bootstrap model -->
                
<script type="text/javascript">
                     

$(document).ready( function () {

$.ajaxSetup({
    headers: {
    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

$('#image').change(function(){
       
  let reader = new FileReader();

  reader.onload = (e) => { 
    $('#preview-image').attr('src', e.target.result); 
  }

  reader.readAsDataURL(this.files[0]); 

});

$('#datatable-ajax-crud').DataTable({
       processing: true,
       serverSide: true,
       ajax: "<?php echo e(route('products')); ?>",
       columns: [
                {data: 'id', name: 'id', 'visible': false},
                
                {data: 'image', name: 'foto' , 
                render: function( data, type, full, meta ) {
                  return '<img src="'+data+'">'
                },orderable: false},
                {data: 'ad', name: 'ad' },
                {data: 'brand', name: 'brand' },
                {data: 'alis', name: 'alis' },
                {data: 'satis', name: 'satis' },
                {data: 'miqdar', name: 'miqdar' },
                {data: 'created_at' },
                {data: 'action', name: 'action', orderable: false},
             ],
      order: [[0, 'desc']],
      dom: 'Bfrltip',
      buttons: [
        {
          extend: 'copyHtml5',
          exportOptions: {
          columns: [0,2,3,4,5,6,7],
          }
        },

        {
          extend: 'csvHtml5',
          exportOptions: {
          columns: [0,2,3,4,5,6,7],
          }
        },

        {
          extend: 'pdfHtml5',
          exportOptions: {
          columns: [0,2,3,4,5,6,7],
          }
        },

        {
          extend: 'print',
          exportOptions: {
          columns: [0,2,3,4,5,6,7],
          }
        },

        {
          extend: 'excel',
          exportOptions: {
          columns: [0,2,3,4,5,6,7],
          }
        }
      ]
  });

$('#addNewBook').click(function () {
   $('#addEditBookForm').trigger("reset");
   $('#ajaxBookModel').html("Daxil et");
   $('#ajax-book-model').modal('show');
   $("#image").attr("required", "true");
   $('#id').val('');
   $('#preview-image').attr('src', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSM4sEG5g9GFcy4SUxbzWNzUTf1jMISTDZrTw&usqp=CAU');
});

$('body').on('click', '.edit', function () {

    var id = $(this).data('id');
     
    // ajax
    $.ajax({
        type:"POST",
        url: "<?php echo e(url('products_edit')); ?>",
        data: { id: id },
        dataType: 'json',
        success: function(res){
          $('#ajaxBookModel').html("Redaktə");
          $('#ajax-book-model').modal('show');
          $('#id').val(res.id);
          $('#ad').val(res.ad);
          $('#brend_id').val(res.brend_id);
          $('#alis').val(res.alis);
          $('#satis').val(res.satis);
          $('#miqdar').val(res.miqdar);
          $('#image').removeAttr('required');
       }
    });
});

$('body').on('click', '.delete', function () {

   if (confirm("Məhsulu silmək istəyirsinizmi?") == true) {
    var id = $(this).data('id');
     
    // ajax
    $.ajax({
        type:"POST",
        url: "<?php echo e(url('products_delete')); ?>",
        data: { id: id },
        dataType: 'json',
        success: function(res){
          var oTable = $('#datatable-ajax-crud').dataTable();
          oTable.fnDraw(false);
        },
        error: function(data){
          alert('Bu mehsulu silmək üçün məhsula aid sifarişləri ləğv edin');
        }
    });
   }
});

$('#addEditBookForm').submit(function(e) {

 e.preventDefault();

 var formData = new FormData(this);

 $.ajax({
    type:'POST',
    url: "<?php echo e(url('products_ins')); ?>",
    data: formData,
    cache:false,
    contentType: false,
    processData: false,
    success: (data) => {
      $("#ajax-book-model").modal('hide');
      var oTable = $('#datatable-ajax-crud').dataTable();
      oTable.fnDraw(false);
      $("#btn-save").html('Submit');
      $("#btn-save"). attr("disabled", false);
    },
    error: function(data){
       console.log(data);
     }
   });
});
});
</script>
</div>  
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Müəllif hüquqlari qorunur 2022</span>
          </div>
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Beybala Muxtarov <a href="http://127.0.0.1:8000/" target="_blank">Anbar</a></span> 
          </div>
        </footer> 
        <!-- partial -->
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <script src="<?php echo e(url('vendors/datatables.net-bs4/dataTables.bootstrap4.js')); ?>"></script>
  <script src="<?php echo e(url('js/dataTables.select.min.js')); ?>"></script>

  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="<?php echo e(url('js/off-canvas.js')); ?>"></script>
  <script src="<?php echo e(url('js/settings.js')); ?>"></script>
  <script src="<?php echo e(url('js/todolist.js')); ?>"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="<?php echo e(url('js/dashboard.js')); ?>"></script>
  <script src="<?php echo e(url('js/Chart.roundedBarCharts.js')); ?>"></script>
  <script src="<?php echo e(url('../../js/file-upload.js')); ?>"></script>
  <!-- End custom js for this page-->
  <!-- End custom js for this page-->
</body>
</html>
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\anbar\resources\views/products.blade.php ENDPATH**/ ?>