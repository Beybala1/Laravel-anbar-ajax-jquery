<?php if($foto): ?>
<img src="<?php echo e(Storage::url($foto)); ?>" height="75" width="75" alt="" />
<?php else: ?>
<img src="https://www.riobeauty.co.uk/images/product_image_not_found.gif" alt="" height="75" width="75">
<?php endif; ?><?php /**PATH C:\xampp\htdocs\anbar\resources\views/image.blade.php ENDPATH**/ ?>