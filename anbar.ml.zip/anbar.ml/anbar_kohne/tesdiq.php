<?php

$con = mysqli_connect('localhost','filmbaxt_beybala','beybala1','filmbaxt_laravel_anbar');

$tesdiq = 0;
$sec = mysqli_query($con,"select * from users where tesdiq = 0");
while($info=mysqli_fetch_array($sec)){
    
    if(md5($info['email'])==$_GET['eid'])
    {
        $tesdiq = 1;
        
        $update = mysqli_query($con,"update users set tesdiq = 1 where email='".$info['email']."'");
        
        if($update==true){
            header("Location: https://anbar.ml/login");
            echo'Profiliniz uğurla tesdiq edildi';
            exit();
        }
    }
}

if($tesdiq == 0){
    header("Location: https://anbar.ml/qeydiyyat");
    echo'Profiliniz təsdiq edilmədi';
    exit();
}
?>