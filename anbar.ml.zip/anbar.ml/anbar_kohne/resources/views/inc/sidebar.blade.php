  <!-- partial:partials/_sidebar.html -->
  <nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link" href="https://anbar.ml/">
          <ion-icon size="large" name="person-outline"></ion-icon>
          <span style="margin: 0 30px" class="menu-title">Müştəri</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="https://anbar.ml/brands">
          <ion-icon size="large" name="bookmark-outline"></ion-icon>
          <span style="margin: 0 30px" class="menu-title">Brend</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="https://anbar.ml/products">
          <ion-icon size="large" name="shirt-outline"></ion-icon>
          <span style="margin: 0 30px" class="menu-title">Məhsul</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="https://anbar.ml/orders">
          <ion-icon size="large" name="bag-handle-outline"></ion-icon>
          <span style="margin: 0 30px" class="menu-title">Sifariş</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="https://anbar.ml/xerc">
          <ion-icon size="large" name="cash-outline"></ion-icon>
          <span style="margin: 0 30px" class="menu-title">Xərc</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="https://anbar.ml/employee">
          <ion-icon size="large" name="people-outline"></ion-icon>
          <span style="margin: 0 30px" class="menu-title">İşçilər</span>
        </a>
      </li>
      <!--
      <li class="nav-item">
        <a class="nav-link" href="https://anbar.ml/orders">
          <ion-icon size="large" name="checkmark-done-outline"></ion-icon>
          <span style="margin: 0 30px" class="menu-title">Tapşırıq</span>
        </a>
      </li>-->
  </nav>
  <!-- partial -->