<div class="main-panel">
  <div class="content-wrapper">
    <div class="row">
      <div class="col-md-12 grid-margin transparent">
        <div class="row">
          <div class="col-md-2 mb-4 mb-lg-0 stretch-card transparent">
            <div class="card card-tale">
              <a style="text-decoration:none; color:white;" href="https://anbar.ml/">
                <div class="card-body">
                  <p class="mb-4">Toplam müştəri</p>
                  <p class="fs-30 mb-2">{{$total_client}}</p>
                </div>
              </a>
            </div>
          </div>
          <div class="col-md-2 mb-4 mb-lg-0 stretch-card transparent">
            <div class="card card-dark-blue">
              <a style="text-decoration:none; color:white;" href="https://anbar.ml/brands">
                <div class="card-body">
                  <p class="mb-4">Toplam brend</p>
                  <p class="fs-30 mb-2">{{$total_brand}}</p>
                </div>
              </a>
            </div>
          </div>
          <div class="col-md-2 mb-4 mb-lg-0 stretch-card transparent">
            <div class="card card-light-blue">
              <a style="text-decoration:none; color:white;" href="https://anbar.ml/products">
                <div class="card-body">
                  <p class="mb-4">Toplam məhsul</p>
                  <p class="fs-30 mb-2">{{$total_product}}</p>
                </div>
              </a>
            </div>
          </div>
          <div class="col-md-2 mb-4 mb-lg-0 stretch-card transparent">
            <div class="card card-light-danger">
              <a style="text-decoration:none; color:white;" href="https://anbar.ml/orders">
                <div class="card-body">
                  <p class="mb-4">Toplam sifariş</p>
                  <p class="fs-30 mb-2">{{$total_order}}</p>
                </div>
              </a>
            </div>
          </div>

          @php($alis = 0)
          @php($satis = 0)
          @php($miqdar = 0)
          @php($qazanc = 0)

          @foreach($products_data as $p)
          @php($qazanc = (($p->satis - $p->alis)*$p->miqdar)+$qazanc)
          @endforeach

          <div class="col-md-2 mb-4 mb-lg-0 stretch-card transparent">
            <div class="card card-light-danger">
              <a style="text-decoration:none; color:white;" href="https://anbar.ml/orders">
                <div class="card-body">
                  <p class="mb-4">Toplam qazanc</p>
                  <p class="fs-30 mb-2">{{$qazanc}}</p>
                </div>
              </a>
            </div>
          </div>

          @php($cqazanc = 0)

          @foreach ($orders_data as $order_qazanc)
          @if($order_qazanc->tesdiq==1)
          @php($cqazanc = (($order_qazanc->satis - $order_qazanc->alis)*$order_qazanc->order_miqdar)+$cqazanc)
          @endif
          @endforeach

          <div class="col-md-2 mb-4 mb-lg-0 stretch-card transparent">
            <div class="card card-light-danger">
              <a style="text-decoration:none; color:white;" href="https://anbar.ml/orders">
                <div class="card-body">
                  <p class="mb-4">Cari qazanc</p>
                  <p class="fs-30 mb-2">{{$cqazanc}}</p>
                </div>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>