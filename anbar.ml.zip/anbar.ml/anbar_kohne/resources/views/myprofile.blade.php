@extends('layouts.app');

@section('myprofile')

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">  
<link  href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

<div class="col-12 grid-margin stretch-card">
    <div class="card">
        <div class="card-body">
            <h2 class="card-title">Profil</h2>

            @if ($errors->any)
                @foreach ($errors->all() as $sehv)
                    <div class="alert alert-danger" role="alert">
                        {{$sehv}}<br><br>
                    </div>
                @endforeach
            @endif

            @if(session('success'))
                <div class="alert alert-success" role="alert">
                    {{session('success')}}<br><br>
                </div>
            @endif

            @if(session('fail'))
                <div class="alert alert-danger" role="alert">
                    {{session('fail')}}<br><br>
                </div>
            @endif

            <form class="forms-sample" method="post" action="{{url('myprofile_ins')}}" enctype="multipart/form-data">
                @csrf

                <label>Foto</label>
                <div class="col-sm-13">
                    <input type="file"  class="form-control" id="image" name="foto" value="{{ Auth::user()->foto }}">
                    <input type="hidden" name="carifoto" value="{{ Auth::user()->foto }}">
                    <img src="{{url(Auth::user()->foto)}}">                
                </div>
            
                <div class="form-group">
                    <label for="exampleInputName1">Ad</label>
                    <input type="text" class="form-control" name="ad" value="{{ Auth::user()->name }}" id="exampleInputName1" placeholder="Ad" required="">
                </div>

                <div class="form-group">
                    <label for="exampleInputName1">Email</label>
                    <input type="email" class="form-control" name="email" value="{{ Auth::user()->email }}" id="exampleInputName1" placeholder="Email" required="">
                </div>

                <div class="form-group">
                    <label for="exampleInputName1">Cari parol</label>
                    <input type="password" class="form-control" name="cari_parol" id="exampleInputName1" placeholder="Cari parol" required="">
                </div>

                <div class="form-group">
                    <label for="exampleInputName1">Yeni parol</label>
                    <input type="password" class="form-control" name="yeni_parol" id="exampleInputName1" placeholder="Yeni parol">
                </div>

                <div class="form-group">
                    <label for="exampleInputName1">Təkrar parol</label>
                    <input type="password" class="form-control" name="parol_t" id="exampleInputName1" placeholder="Təkrar parol">
                </div>
                <button type="submit" class="btn btn-primary mr-2">Yenilə</button>
                <!--<button class="btn btn-light">Cancel</button>-->
            </form>
        </div>
    </div>
</div>
@endsection
