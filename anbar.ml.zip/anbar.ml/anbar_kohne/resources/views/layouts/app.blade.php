<div class="container-scroller">
    @include('inc.navbar')
    <div class="container-fluid page-body-wrapper">
        @include('inc.sidebar')
        @include('inc.statistika')
        @yield('clients')
        @yield('brands')
        @yield('xerc')
        @yield('products')
        @yield('orders')
        @yield('myprofile')
        @yield('employee')
        @include('inc.footer')
    </div>
</div>
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
<script src="{{url('vendors/datatables.net-bs4/dataTables.bootstrap4.js')}}"></script>
<script src="{{url('js/dataTables.select.min.js')}}"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0/dist/Chart.min.js"></script>
<!-- End plugin js for this page -->
<!-- inject:js -->
<script src="{{url('js/off-canvas.js')}}"></script>
<script src="{{url('js/settings.js')}}"></script>
<script src="{{url('js/todolist.js')}}"></script>
<!-- endinject -->
<!-- Custom js for this page-->
<script src="{{url('js/dashboard.js')}}"></script>
<script src="{{url('../../js/file-upload.js')}}"></script>